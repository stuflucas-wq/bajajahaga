#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR="${1:-/var/www/qris-bridge}"
[[ "${EUID}" -eq 0 ]] || { echo 'Jalankan dengan sudo: sudo bash fix-qris-minimum-rp1.sh'; exit 1; }
[[ -f "$APP_DIR/artisan" ]] || { echo "Laravel QRIS tidak ditemukan di $APP_DIR"; exit 1; }
command -v python3 >/dev/null || { echo 'python3 tidak tersedia'; exit 1; }
command -v php >/dev/null || { echo 'PHP tidak tersedia'; exit 1; }

python3 - "$APP_DIR" <<'PY'
from pathlib import Path
import datetime, os, shutil, sys

app = Path(sys.argv[1]).resolve()
patches = {
    'app/Services/QrisOrderService.php': [
        (
            'if ($amount < 1000 || $amount > 10000000)',
            'if ($amount < 1 || $amount > 10000000)',
        ),
        (
            '''                $offsets = range(1, 999);
                shuffle($offsets);''',
            '''                $offsets = range(1, 999);
                shuffle($offsets);
                // Untuk harga Rp1-Rp999, utamakan nominal persis bila belum dipakai.
                // Jika nominal sudah dipakai invoice lain, gunakan kode unik.
                if ($baseAmount < 1000) {
                    array_unshift($offsets, 0);
                }''',
        ),
    ],
    'app/Services/QrisNotificationParser.php': [
        ('return $amount >= 1000 && $amount <= 10000000 ? $amount : null;',
         'return $amount >= 1 && $amount <= 10000000 ? $amount : null;'),
    ],
    'app/Http/Controllers/QrisAdminController.php': [
        ("'min:1000'", "'min:1'"),
    ],
    'resources/views/qris/admin.blade.php': [
        ('name="price" type="number" min="1000"', 'name="price" type="number" min="1"'),
    ],
}

# Preflight all edits before touching any file, to avoid partial installation.
edits = {}
for name, substitutions in patches.items():
    src = app / name
    if not src.is_file():
        raise SystemExit(f'ERROR: File tidak ditemukan: {src}')
    before = src.read_text(encoding='utf-8')
    after = before
    for old, new in substitutions:
        old_count = after.count(old)
        if old_count == 1:
            after = after.replace(old, new, 1)
        elif old_count == 0 and new in after:
            pass  # Already patched
        else:
            raise SystemExit(f'ERROR: Struktur kode berbeda dari paket yang dibuat sebelumnya: {name} ({old[:45]!r}). Tidak mengubah file apa pun.')
    if after != before:
        edits[name] = (src, after)

if not edits:
    print('Sudah menggunakan batas Rp1. Tidak ada file yang diubah.')
    sys.exit(0)

stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
backup = Path('/var/backups') / f'qris-minimum-rp1-{stamp}'
for name, (src, _) in edits.items():
    dest = backup / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(src, dest)

for name, (src, after) in edits.items():
    temp = src.with_name(src.name + '.rp1-tmp')
    shutil.copy2(src, temp)
    temp.write_text(after, encoding='utf-8')
    os.replace(temp, src)
    print('UPDATED:', name)
print('BACKUP:', backup)
PY

php -l "$APP_DIR/app/Services/QrisOrderService.php"
php -l "$APP_DIR/app/Services/QrisNotificationParser.php"
php -l "$APP_DIR/app/Http/Controllers/QrisAdminController.php"
php -r 'require $argv[1]; $p = new \App\Services\QrisNotificationParser(); if ($p->parse("Pembayaran diterima", "QRIS Rp1 diterima") !== 1 || $p->parse("Pembayaran diterima", "QRIS Rp0 diterima") !== null) { exit(1); } echo "Parser nominal Rp1: OK\n";' "$APP_DIR/app/Services/QrisNotificationParser.php"

if id -u www-data >/dev/null 2>&1; then
    (cd "$APP_DIR" && runuser -u www-data -- php artisan optimize:clear)
else
    (cd "$APP_DIR" && php artisan optimize:clear)
fi
echo
echo 'SELESAI: harga produk, invoice, parser notifikasi, dan kolom harga kini menerima Rp1.'
echo 'Keterangan: QR nominal rendah dapat bertambah kode unik jika nominal persis sudah digunakan.'
echo 'Keamanan: QRIS_AUTO_CONFIRM tidak diubah; notifikasi tidak otomatis membuktikan dana diterima.'
echo 'Cek transaksi masuk di dashboard /qris-admin dan riwayat resmi GoPay Merchant.'

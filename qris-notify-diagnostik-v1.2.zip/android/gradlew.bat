@echo off
setlocal
set "ROOT=%~dp0"
set "JAR=%ROOT%gradle\wrapper\gradle-wrapper.jar"
set "EXPECTED=cb0da6751c2b753a16ac168bb354870ebb1e162e9083f116729cec9c781156b8"
if not exist "%JAR%" (
  echo Downloading official Gradle 8.7 wrapper JAR...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.7-wrapper.jar' -OutFile '%JAR%'"
  if errorlevel 1 exit /b 1
)
for /f "tokens=*" %%h in ('powershell -NoProfile -Command "(Get-FileHash -Algorithm SHA256 '%JAR%').Hash.ToLower()"') do set "ACTUAL=%%h"
if not "%ACTUAL%"=="%EXPECTED%" (
  echo ERROR: Gradle wrapper checksum mismatch. Do not execute.
  exit /b 1
)
java -classpath "%JAR%" org.gradle.wrapper.GradleWrapperMain %*

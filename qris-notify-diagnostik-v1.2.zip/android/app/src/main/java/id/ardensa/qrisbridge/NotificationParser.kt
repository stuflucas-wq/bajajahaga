package id.ardensa.qrisbridge

import java.security.MessageDigest

object NotificationParser {
    const val GOPAY_PACKAGE = "com.gojek.gopaymerchant"
    private val positive = Regex("berhasil|sukses|diterima|menerima|pembayaran masuk|uang masuk|transaksi masuk|terima pembayaran", RegexOption.IGNORE_CASE)
    private val negative = Regex("gagal|dibatalkan|batal|refund|pengembalian|dikembalikan|tertunda|pending|menunggu|diproses|belum berhasil|belum diterima", RegexOption.IGNORE_CASE)
    private val rupiah = Regex("\\bRp\\s*[0-9][0-9.]*", RegexOption.IGNORE_CASE)

    fun isLikelyPayment(title: String, text: String): Boolean {
        val combined = "$title $text"
        return positive.containsMatchIn(combined) && !negative.containsMatchIn(combined)
            && rupiah.containsMatchIn(combined)
    }

    fun sha256(raw: String): String = MessageDigest.getInstance("SHA-256")
        .digest(raw.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}

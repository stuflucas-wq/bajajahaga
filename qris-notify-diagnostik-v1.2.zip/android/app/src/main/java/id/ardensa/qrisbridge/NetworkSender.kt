package id.ardensa.qrisbridge

import android.content.Context
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object NetworkSender {
    fun deliver(context: Context, payload: JSONObject): Boolean {
        val endpoint = ConfigStore.endpoint(context)
        val deviceId = ConfigStore.deviceId(context)
        val secret = ConfigStore.secret(context)
        if (!endpoint.startsWith("https://") || !endpoint.endsWith("/api/qris/notification")
            || deviceId.isEmpty() || secret.length < 32) {
            BridgeDiagnostics.record(context,"network", "GAGAL KONFIGURASI: URL HTTPS / Device ID / secret")
            return false
        }
        val timestamp = (System.currentTimeMillis() / 1000L).toString()
        val nonce = UUID.randomUUID().toString()
        val body = payload.toString()
        val canonical = "$timestamp\n$nonce\n$body"
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        val signature = mac.doFinal(canonical.toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }
        var connection: HttpURLConnection? = null
        return try {
            connection = URL(endpoint).openConnection() as HttpURLConnection
            connection.requestMethod = "POST"
            connection.connectTimeout = 10000
            connection.readTimeout = 10000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json")
            connection.setRequestProperty("Accept", "application/json")
            connection.setRequestProperty("X-Device-Id", deviceId)
            connection.setRequestProperty("X-Timestamp", timestamp)
            connection.setRequestProperty("X-Nonce", nonce)
            connection.setRequestProperty("X-Signature", signature)
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = connection.responseCode
            val response = try {
                (if (code in 200..299) connection.inputStream else connection.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
            } catch (_: Exception) { "" }
            // Do not include endpoint, credentials, or full notifications in network diagnostics.
            val result = try {
                val obj = JSONObject(response)
                obj.optString("status", obj.optString("error", "respons kosong"))
            } catch (_: Exception) { "respons tidak dikenali" }
            BridgeDiagnostics.record(context,"network", "HTTP $code | $result")
            code == 200
        } catch (e: Exception) {
            BridgeDiagnostics.record(context,"network", "GAGAL JARINGAN: ${e.javaClass.simpleName}: ${e.message.orEmpty().take(75)}")
            false
        } finally { connection?.disconnect() }
    }
}

package id.ardensa.qrisbridge

import android.content.Context

/** Only the official GoPay Merchant notification package is logged. No credentials logged. */
object BridgeDiagnostics {
    private const val PREFS = "qris_bridge_diagnostics"
    fun record(context: Context, key: String, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(key, "${java.text.SimpleDateFormat("dd-MM HH:mm:ss", java.util.Locale("id", "ID")).format(java.util.Date())} | ${value.take(180)}").apply()
    }
    fun get(context: Context, key: String): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, "belum ada") ?: "belum ada"
}

package id.ardensa.qrisbridge

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && NotificationQueue.size(context) > 0) {
            UploadJobService.schedule(context)
        }
    }
}

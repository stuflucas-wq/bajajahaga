package id.ardensa.qrisbridge

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONObject

class GoPayNotificationListener : NotificationListenerService() {
    companion object {
        @Volatile private var connected: GoPayNotificationListener? = null

        fun scanNow(): String {
            val service = connected ?: return "SERVICE BELUM TERHUBUNG — coba tombol Hubungkan ulang"
            return service.scanRecentMerchantNotifications()
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        connected = this
        BridgeDiagnostics.record(applicationContext, "service", "TERHUBUNG ke Android Notification Manager")
        scanRecentMerchantNotifications()
    }

    override fun onListenerDisconnected() {
        connected = null
        BridgeDiagnostics.record(applicationContext, "service", "TERPUTUS — perlu hubungkan ulang")
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        if (connected === this) connected = null
        BridgeDiagnostics.record(applicationContext, "service", "Service dihentikan")
        super.onDestroy()
    }

    private fun scanRecentMerchantNotifications(): String {
        return try {
            val all = activeNotifications ?: emptyArray<StatusBarNotification>()
            val now = System.currentTimeMillis()
            val recent = all.filter { it.packageName == NotificationParser.GOPAY_PACKAGE
                && now - it.postTime in 0..600000L }
            val msg = "Aktif: ${all.size} semua aplikasi; GoPay Merchant 10 menit terakhir: ${recent.size}"
            BridgeDiagnostics.record(applicationContext, "scan", msg)
            recent.forEach { processMerchantNotification(it) }
            msg
        } catch (e: Exception) {
            val msg = "GAGAL scan: ${e.javaClass.simpleName}"
            BridgeDiagnostics.record(applicationContext, "scan", msg)
            msg
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        // Privacy: do not retain titles, text, or package IDs from other apps.
        val isMerchant = sbn.packageName == NotificationParser.GOPAY_PACKAGE
        BridgeDiagnostics.record(applicationContext, "received",
            if (isMerchant) "Event GoPay Merchant diterima" else "Event aplikasi lain diterima")
        if (isMerchant) processMerchantNotification(sbn)
    }

    private fun processMerchantNotification(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: run {
            BridgeDiagnostics.record(applicationContext, "listener", "GoPay Merchant diterima, extras kosong")
            return
        }
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty().take(200)
        val pieces = mutableListOf<String>()
        for (field in listOf(Notification.EXTRA_TEXT, Notification.EXTRA_BIG_TEXT,
                Notification.EXTRA_SUB_TEXT, Notification.EXTRA_SUMMARY_TEXT)) {
            extras.getCharSequence(field)?.toString()?.trim()?.takeIf { it.isNotBlank() }
                ?.let { if (!pieces.contains(it)) pieces.add(it) }
        }
        extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)?.forEach { part ->
            part?.toString()?.trim()?.takeIf { it.isNotBlank() }
                ?.let { if (!pieces.contains(it)) pieces.add(it) }
        }
        val body = pieces.joinToString(" | ").take(500)
        val looksLikePayment = NotificationParser.isLikelyPayment(title, body)
        BridgeDiagnostics.record(applicationContext, "listener",
            "GoPay Merchant: ${if (looksLikePayment) "TERDETEKSI" else "DILEWATI"} | $title | $body")
        if (!looksLikePayment) return
        val hashSource = "${sbn.packageName}|${sbn.key}|${sbn.postTime}|$title|$body"
        val payload = JSONObject().apply {
            put("event_id", NotificationParser.sha256(hashSource))
            put("package_name", sbn.packageName)
            put("title", title.ifBlank { "Notifikasi GoPay Merchant" })
            put("text", body)
            put("posted_at_ms", sbn.postTime)
        }
        if (NotificationQueue.enqueue(applicationContext, payload)) {
            BridgeDiagnostics.record(applicationContext, "queue", "NOTIFIKASI MASUK ANTREAN")
            UploadJobService.schedule(applicationContext)
        } else {
            BridgeDiagnostics.record(applicationContext, "queue", "GAGAL: antrean penuh (500)")
        }
    }
}

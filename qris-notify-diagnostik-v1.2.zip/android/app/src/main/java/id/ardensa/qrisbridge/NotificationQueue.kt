package id.ardensa.qrisbridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object NotificationQueue {
    private const val PREF = "notification_queue"
    private const val KEY = "events"

    @Synchronized
    fun enqueue(context: Context, payload: JSONObject): Boolean {
        val items = all(context)
        val id = payload.getString("event_id")
        for (i in 0 until items.length()) if (items.getJSONObject(i).getString("event_id") == id) return true
        if (items.length() >= 500) return false // Never silently evict a possible payment.
        items.put(payload)
        persist(context, items)
        return true
    }

    @Synchronized
    fun first(context: Context): JSONObject? {
        val items = all(context)
        return if (items.length() > 0) items.optJSONObject(0) else null
    }

    @Synchronized
    fun remove(context: Context, eventId: String) {
        val source = all(context)
        val remaining = JSONArray()
        for (i in 0 until source.length()) {
            val item = source.getJSONObject(i)
            if (item.getString("event_id") != eventId) remaining.put(item)
        }
        persist(context, remaining)
    }

    @Synchronized
    fun size(context: Context) = all(context).length()

    private fun all(context: Context): JSONArray {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
    }

    private fun persist(context: Context, array: JSONArray) {
        // commit() is durable before scheduling the network job.
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).commit()
    }
}

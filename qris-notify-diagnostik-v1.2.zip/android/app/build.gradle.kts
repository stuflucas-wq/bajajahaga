plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "id.ardensa.qrisbridge"
    compileSdk = 35
    defaultConfig {
        applicationId = "id.ardensa.qrisbridge"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2-diagnostik"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

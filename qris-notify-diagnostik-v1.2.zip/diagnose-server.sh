#!/usr/bin/env bash
set -Eeuo pipefail
APP="${1:-/var/www/qris-bridge}"
[[ -f "$APP/artisan" ]] || { echo "Laravel tidak ditemukan: $APP"; exit 1; }
cd "$APP"
for service in nginx postgresql; do echo "SERVICE $service: $(systemctl is-active "$service" 2>/dev/null || true)"; done
echo '=== ROUTES QRIS ==='
php artisan route:list --path=qris --compact 2>/dev/null || php artisan route:list --path=qris || true
echo '=== DATABASE QRIS (read-only, tanpa secret) ==='
runner=(php)
if [[ "$EUID" -eq 0 ]] && id www-data >/dev/null 2>&1; then runner=(runuser -u www-data -- php); fi
"${runner[@]}" -r '
require "vendor/autoload.php";
$app = require "bootstrap/app.php";
$app->make(Illuminate\Contracts\Console\Kernel::class)->bootstrap();
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
echo "Auto-confirm: ".(filter_var(config("qris_bridge.auto_confirm"), FILTER_VALIDATE_BOOL)?"AKTIF":"NONAKTIF")."\n";
echo "Auto-confirm nominal tanpa RRN: ".(filter_var(config("qris_bridge.amount_only_auto_confirm", false),FILTER_VALIDATE_BOOL)?"AKTIF (HEURISTIK)":"NONAKTIF")."\n";
if (Schema::hasTable("qris_notifications")) {
  echo "Event masuk: ".DB::table("qris_notifications")->count()."\n";
  foreach(DB::table("qris_notifications")->orderByDesc("id")->limit(10)->get(["id","status","amount","event_at","order_id"]) as $r)
    echo "  notif #{$r->id} | status={$r->status} | Rp".($r->amount??"-")." | {$r->event_at} | order=".($r->order_id??"-")."\n";
} else echo "TABEL qris_notifications BELUM ADA\n";
if (Schema::hasTable("qris_orders")) {
  echo "Order terbaru:\n";
  foreach(DB::table("qris_orders")->orderByDesc("id")->limit(10)->get(["invoice","status","amount","created_at","expires_at"]) as $o)
    echo "  {$o->invoice} | {$o->status} | Rp{$o->amount} | dibuat={$o->created_at} | exp={$o->expires_at}\n";
} else echo "TABEL qris_orders BELUM ADA\n";
'
echo '=== DIAGNOSIS ==='
echo 'Belum ada event baru -> listener Android/izin/HTTPS/HMAC perlu dicek.'
echo 'invalid_format -> parser gagal atau nominal di bawah batas, periksa patch Rp1.'
echo 'unmatched -> nominal tidak sama atau invoice sudah habis/expired.'
echo 'matched_review -> notifikasi berhasil; order menunggu verifikasi merchant.'
echo 'auto_paid -> heuristik berhasil, wajib rekonsiliasi ke riwayat GoPay.'

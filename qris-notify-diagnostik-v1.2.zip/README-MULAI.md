# QRIS Notify Bridge v1.2 — listener connectivity diagnostics

**Paket source Android + patch server sama seperti v1.1. Bukan APK siap instal.** Tidak menghapus order, database, atau token. Gunakan GitHub Actions yang tersedia untuk membangun APK.

### Mengapa v1.2?

Bukti di HP: notifikasi `Pembayaran QRIS statis diterima — Rp 1 di BACKMEE.` muncul, tetapi APK v1.1 melaporkan `Akses notifikasi: AKTIF`, `Notifikasi terakhir: belum ada`, antrean 0, dan tes API `HTTP 200 invalid_format`. Ini mengarah ke service `NotificationListenerService` belum menerima event. HTTP 200 invalid_format hanyalah tes koneksi.

### Build dan instal

1. Unggah **isi** ZIP (bukan ZIP sebagai satu file) ke root repo GitHub **private** yang sebelumnya dipakai build source Android; timpa file versi lama, termasuk `.github`.
2. Buka GitHub → Actions → **Build QRIS Notify Bridge Diagnostic APK** → **Run workflow**, unduh artifact `QRIS-Notify-Bridge-v1.2-Diagnostic`, ekstrak dan install `app-debug.apk`.
3. ID aplikasi sama dan versionCode=3. Jika signing key berubah dan update gagal, catat endpoint/device ID/secret dengan aman, pastikan antrean lama kosong, lalu uninstall versi lama dan install yang baru. Uninstall menghilangkan konfigurasi dan antrean lokal.
4. Buka Pengaturan → Akses notifikasi → matikan dan hidupkan kembali izin **QRIS Notify Bridge**. Bila OS membatasi aplikasi sideload, izinkan akses hanya jika sudah meninjau source dan mempercayainya. Setel baterai aplikasi agar tidak dibatasi.
5. Buka APK, simpan endpoint, Device ID, dan secret seperti sebelumnya. Klik **Hubungkan ulang service listener**, lalu **Scan notifikasi GoPay yang masih aktif**. Gunakan `Refresh diagnostik` dan salin hasilnya.

### Menafsirkan diagnostik

- `Status listener: belum ada/TERPUTUS` → service belum berhasil terhubung. Coba toggle akses notifikasi/rebind, pastikan GoPay Merchant dan Bridge terinstal di profil Android yang sama.
- `Status listener: TERHUBUNG`, `Scan ... GoPay Merchant: 0` → notifikasi sudah hilang dari notifikasi aktif, lebih lama dari 10 menit, diblokir pada profil yang berbeda, atau Android tidak menyediakannya; lakukan pembayaran uji *baru* jika memang perlu setelah invoice pending dibuat. Jangan memproses ulang transfer lama untuk invoice baru.
- `Event Android terakhir: Event aplikasi lain diterima` → service berhasil mendapat notifikasi Android, belum melihat notifikasi merchant.
- `Notifikasi terakhir: GoPay Merchant: TERDETEKSI` → listener membaca sukses, cek antrean dan respons API; `HTTP 200 | invalid_format` dari tombol tes normal, tapi tidak normal jika berasal dari notifikasi merchant.
- `Antrean menunggu: 0` saja tidak membuktikan berhasil: event yang berhasil terkirim akan dihapus dari antrean. Gunakan riwayat event server (`sudo bash diagnose-server.sh`).

Catatan: pemindaian hanya memproses notifikasi GoPay Merchant yang **masih aktif** dan di-post dalam 10 menit. Tidak dapat mengambil riwayat notifikasi yang sudah dihapus. Pemindaian tidak membuat pembayaran palsu.

### Backend

Bila sebelumnya sudah memasang patch backend v1.1, **tidak perlu** memasang ulang. Perintah diagnostik VPS:

```bash
cd /root/qris-notify-diagnostik-v2
sudo bash diagnose-server.sh
```

Hasil notifikasi bukan bukti settlement. Untuk auto-paid produksi, gunakan konfirmasi QRIS resmi dari acquirer; hanya lakukan pengiriman barang digital setelah verifikasi.

---

# QRIS Notify Bridge v1.1 — diagnostik notifikasi GoPay Merchant + patch server

Paket ini terdiri dari **source project Android** (bukan APK siap instal), workflow build APK melalui GitHub Actions, dan patch Laravel untuk instalasi `/var/www/qris-bridge`. Dibuat berdasarkan screenshot asli **"Pembayaran QRIS statis diterima — Rp 30 di BACKMEE"**. Tidak mengubah credential atau menghapus database.

## Langkah 1 — Perbaiki backend di VPS

Upload seluruh folder ekstraksi ke VPS (mis. `/root/qris-notify-diagnostik-v2/`). Di SSH:

```bash
cd /root/qris-notify-diagnostik-v2
sudo bash fix-server.sh
```

Perintah ini memperbaiki batas minimum harga, invoice, dan parser menjadi **Rp1**, melakukan PHP lint, clear cache, lalu menampilkan 10 event terakhir dari `qris_notifications` serta order terakhir. File yang diubah di-backup ke `/var/backups/`. Jika sebelumnya patch Rp1 sudah dipasang, tidak diduplikasi.

Cek kapan saja (hanya baca data, tidak mengubah pembayaran):

```bash
sudo bash diagnose-server.sh
```

**Penafsiran hasil:**
- tidak ada event baru: izin listener/antrean/API/HTTPS/HMAC Android belum berhasil
- `invalid_format`: parser pesan merchant gagal atau backend masih punya batas minimum Rp1.000
- `unmatched`: tak ada invoice pending dengan nominal yang sama dalam masa aktif
- `matched_review`: notifikasi sukses sampai, invoice menunggu verifikasi merchant
- `auto_paid`: invoice ditandai berdasarkan heuristik, masih harus direkonsiliasi

## Langkah 2 — Build Android APK v1.1

1. Di GitHub buat repo **private** (atau gunakan repo source Android yang lama). Upload **ISI folder ZIP ke root repo**, termasuk `.github/` dan `android/` (jangan upload ZIP utuh).
2. Buka tab **Actions** → **Build QRIS Notify Bridge Diagnostic APK** → **Run workflow**.
3. Ambil `QRIS-Notify-Bridge-v1.1-Diagnostic` pada **Artifacts** → ekstrak ZIP → install `app-debug.apk`.
4. Versi aplikasi v1.1 (`versionCode=2`, ID aplikasi sama). Jika instalasi gagal akibat tanda tangan APK berbeda, simpan dulu URL, Device ID dan secret secara aman, pastikan antrean lama kosong, baru uninstall versi lama dan install versi baru. Uninstall menghapus antrean dan konfigurasi setempat.
5. Izinkan akses notifikasi di pengaturan Android. Di HP tertentu: **Settings → Apps → QRIS Notify Bridge → Allow restricted settings** (hanya jika yakin dengan source yang diinstall), lalu beri izin notification access. Atur baterai menjadi tidak dibatasi bila perlu.

## Langkah 3 — Uji tanpa transfer uang

1. Buka APK, pastikan endpoint, Device ID, secret masih cocok dengan VPS. Tekan **Simpan konfigurasi**.
2. Tap **Tes koneksi API (tanpa pembayaran)**. Hasil normal di APK: `HTTP 200 | invalid_format` (test memang bukan transaksi).
3. Tap **Refresh diagnostik** / **Salin diagnostik tanpa secret**. Hasil ini bisa dikirim untuk bantuan debugging. Jangan pernah membagikan secret, token bot, password, atau file `.env`.
4. Bila API terhubung, buka dashboard `/qris-admin`, buat **invoice pending** dan cek nominal unik final. Lalu lakukan **satu** pembayaran uji baru ke QRIS milikmu hanya setelah siap. Notifikasi lama sebelum APK terhubung tak bisa selalu diambil ulang dan tak boleh dialokasikan ke invoice baru.
5. Tap **Refresh diagnostik** dan di VPS jalankan `sudo bash diagnose-server.sh`. Cocokkan event dengan `qris_orders`.

APK membaca format notifikasi seperti pada screenshot dan beberapa variasi Android `EXTRA_BIG_TEXT`, `EXTRA_TEXT`, `EXTRA_TEXT_LINES`. Tetap hanya memproses aplikasi dengan paket resmi `com.gojek.gopaymerchant`.

## Mengapa belum otomatis PAID?

Mode aman dari backend masih `QRIS_AUTO_CONFIRM=false`. Jika sudah nyambung dan status event `matched_review`, invoice `payment_detected`, berarti parser benar tetapi konfirmasi masih manual. Versi lama juga mensyaratkan nomor referensi (RRN) untuk auto-paid. Notifikasi contoh BACKMEE **tidak berisi RRN**.

### Mode opt-in auto-paid dari notifikasi (BERISIKO)

Untuk pengguna yang benar-benar memahami bahwa notifikasi HP **bukan webhook resmi/konfirmasi bank**, tersedia mode heuristik terbatas:

```bash
sudo bash fix-server.sh --enable-heuristic
```

Skrip akan meminta ketik **SAYA PAHAM** sebelum mengaktifkan. Ini menambah `QRIS_ALLOW_AMOUNT_ONLY_AUTO_CONFIRM=true`, `QRIS_EXPECTED_MERCHANT_NAME=BACKMEE`, dan `QRIS_AUTO_CONFIRM=true`. Hanya notifikasi GoPay Merchant yang cocok dengan judul sukses QRIS statis, memuat `BACKMEE`, cocok nominal **satu** invoice pending, dalam jendela waktu sempit, dan tidak bentrok dengan order lain 2 jam terakhir yang dapat ditandai paid. Kode asli juga memblokir duplikat event/fingerprint.

**Peringatan kuat:** Nominal+notifikasi tetap bisa salah, telat, spoof, atau tidak benar-benar settled; auto-paid akan dapat mengirim stok digital tanpa verifikasi. Untuk uang/barang riil, cara yang seharusnya dipakai adalah **QRIS via provider dengan callback/webhook resmi terautentikasi**. Gunakan default manual sampai jalur ini tersedia. Untuk menonaktifkan mode heuristik, set `QRIS_AUTO_CONFIRM=false` pada `.env`, lalu `php artisan optimize:clear`.

## Validasi yang sudah dilakukan

- Parser Kotlin menerima contoh `Pembayaran QRIS statis diterima` + `Rp 30 di BACKMEE.`
- Parser PHP versi Rp1 menghasilkan jumlah `30` untuk contoh yang sama
- PHP lint source versi patch: lolos
- Bash script: syntax check lolos

**APK Android final dan pembayaran riil belum diuji pada HP/VPS pengguna.** File APK perlu dibangun di GitHub Actions sesuai petunjuk di atas.

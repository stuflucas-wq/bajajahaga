#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
APP="${QRIS_APP_DIR:-/var/www/qris-bridge}"
[[ "${EUID}" -eq 0 ]] || { echo 'Jalankan dengan sudo'; exit 1; }
[[ -f "$APP/artisan" ]] || { echo "Laravel QRIS tidak ditemukan di $APP"; exit 1; }
if [[ $# -gt 0 && "$1" != '--enable-heuristic' ]]; then echo 'Pilihan: tanpa parameter atau --enable-heuristic'; exit 1; fi
bash "$SCRIPT_DIR/fix-qris-minimum-rp1.sh" "$APP"
if [[ "${1:-}" == '--enable-heuristic' ]]; then
  echo
  echo 'PERINGATAN: nominal+notifikasi BUKAN bukti pembayaran resmi.'
  echo 'Mode ini menganggap PAID berdasarkan satu event unik GoPay Merchant (judul sukses, nama merchant BACKMEE, nominal dan waktu invoice cocok).'
  echo 'Notifikasi bisa dipalsukan/terlambat dan pembayaran salah bisa mengirim barang digital otomatis.'
  echo 'Untuk verifikasi sepenuhnya otomatis gunakan callback resmi penyedia QRIS.'
  if [[ ! -t 0 ]]; then echo 'Harus diaktifkan secara interaktif di SSH.'; exit 2; fi
  read -r -p 'Ketik SAYA PAHAM untuk mengaktifkan mode BERISIKO: ' CONSENT
  [[ "$CONSENT" == 'SAYA PAHAM' ]] || { echo 'Dibatalkan: tetap pakai mode verifikasi admin.'; exit 0; }
  python3 - "$APP" <<'PY'
import sys, datetime, os, shutil
from pathlib import Path
app=Path(sys.argv[1]); p=app/'app/Services/QrisReconciler.php'; c=app/'config/qris_bridge.php'; e=app/'.env'
assert p.is_file() and c.is_file() and e.is_file(), 'File QRIS Laravel tidak lengkap'
old=p.read_text(); config=c.read_text(); env=e.read_text()
anchor='''            $paid = !$otherRecentSameAmount
                && filter_var(config('qris_bridge.auto_confirm', false), FILTER_VALIDATE_BOOL)
                && $reference !== null'''
replacement='''            // Mode heuristik nominal TANPA RRN: opt-in saja, tidak dijamin oleh acquirer.
            $configuredMerchant = trim((string) config('qris_bridge.expected_merchant_name', ''));
            $allowAmountOnly = filter_var(config('qris_bridge.amount_only_auto_confirm', false), FILTER_VALIDATE_BOOL)
                && $configuredMerchant !== ''
                && preg_match('/\\bpembayaran\\s+qris\\s+statis\\s+diterima\\b/iu', $title) === 1
                && stripos($body, $configuredMerchant) !== false;
            $paid = !$otherRecentSameAmount
                && filter_var(config('qris_bridge.auto_confirm', false), FILTER_VALIDATE_BOOL)
                && ($reference !== null || $allowAmountOnly)'''
if anchor in old: new=old.replace(anchor,replacement,1)
elif replacement in old: new=old
else: raise SystemExit('ERROR: QrisReconciler sudah berbeda; tidak diubah.')
confkey="    'auto_confirm' => env('QRIS_AUTO_CONFIRM', false),"
confadd=confkey+"\n    'amount_only_auto_confirm' => env('QRIS_ALLOW_AMOUNT_ONLY_AUTO_CONFIRM', false),\n    'expected_merchant_name' => env('QRIS_EXPECTED_MERCHANT_NAME', ''),"
if confkey in config and "'amount_only_auto_confirm' =>" not in config:
    config2=config.replace(confkey,confadd,1)
elif "'amount_only_auto_confirm' =>" in config: config2=config
else: raise SystemExit('ERROR: qris_bridge.php berbeda; tidak diubah.')
for key,val in [('QRIS_AUTO_CONFIRM','true'),('QRIS_ALLOW_AMOUNT_ONLY_AUTO_CONFIRM','true'),('QRIS_EXPECTED_MERCHANT_NAME','BACKMEE')]:
    lines=env.splitlines(); found=False
    for i,line in enumerate(lines):
        if line.startswith(key+'='):
            lines[i]=key+'='+val;found=True
    if not found: lines.append(key+'='+val)
    env='\n'.join(lines)+'\n'
stamp=datetime.datetime.now().strftime('%Y%m%d-%H%M%S')
backup=Path('/var/backups')/f'qris-autopaid-{stamp}'
backup.mkdir(mode=0o700,parents=True,exist_ok=False)
for path in [p,c,e]:
    dest=backup/path.relative_to(app);dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copy2(path,dest); os.chmod(dest,0o600)
for path,data in [(p,new),(c,config2),(e,env)]:
    tmp=path.with_name(path.name+'.qris-tmp'); shutil.copy2(path,tmp)
    tmp.write_text(data);os.replace(tmp,path)
print('Backup aman:',backup)
PY
  php -l "$APP/app/Services/QrisReconciler.php"
  php -l "$APP/config/qris_bridge.php"
  if id www-data >/dev/null 2>&1; then (cd "$APP" && runuser -u www-data -- php artisan optimize:clear)
  else (cd "$APP" && php artisan optimize:clear); fi
  echo 'AUTO PAID HEURISTIK AKTIF — khusus nominal unik, notifikasi merchant BACKMEE dan invoice dalam jendela waktu yang benar.'
fi
bash "$SCRIPT_DIR/diagnose-server.sh" "$APP"

# QRIS Notify Bridge v1.3 — kirim antrean SEKARANG

Perbaikan v1.2: tombol Kirim ulang antrean dahulu hanya memanggil JobScheduler Android, yang bisa menunda pengiriman saat Doze/baterai rendah. v1.3 menambah pengiriman langsung pada thread saat pengguna menekan tombol. Event tetap disimpan jika jaringan/API gagal. Respons terakhir (`HTTP NNN | status`) dan status pengiriman langsung ditampilkan. JobScheduler tetap berjalan sebagai jalur background, dengan diagnostik jadwal dan eksekusi.

## Untuk repo yang hanya berisi ZIP dan build-apk.yml

1. Upload file ZIP *qris-notify-diagnostik-v1.3.zip* ke root repo (jangan ekstrak, karena workflow saat ini mengekstraknya ke `source`).
2. Di `.github/workflows/build-apk.yml`, ubah nama ZIP pada perintah unzip dari `qris-notify-diagnostik-v1.2.zip` menjadi `qris-notify-diagnostik-v1.3.zip`.
3. Commit dan ambil artefak dari GitHub Actions. Tidak perlu mengganti langkah SDK yang telah berhasil.
4. Install di atas versi 1.2 (applicationId sama, versionCode 4). Selalu backup konfigurasi/antrean sebelum uninstall APK, karena uninstall menghapus antrean lokal.
5. Buka APK, klik **Kirim antrean SEKARANG (langsung)**, tunggu hingga selesai di aplikasi, lalu Refresh dan Salin diagnostik. Pastikan antrean berkurang dan lihat status server (`matched_review`, `unmatched`, `invalid_format`, `auto_paid`).

Jika kamu upload *isi* ZIP dan tidak menggunakan workflow ekstraksi, gunakan file `.github/workflows/build-apk.yml` dari paket ini untuk build langsung dari `android/`.

## Kenapa setelah berhasil kirim belum tentu PAID?

API bisa mengembalikan HTTP 200 dengan status `invalid_format` atau `unmatched`. Hanya event notifikasi yang cocok dengan invoice pending, parser Rp1 aktif, dan kebijakan verifikasi server yang valid dapat mengubah status. Riwayat transaksi harus diverifikasi melalui GoPay Merchant resmi. Mode heuristik nominal saja tidak menjamin pembayaran, dan event terlambat tidak boleh dipaksakan menjadi PAID. Jangan membuat invoice baru untuk mengklaim pembayaran lama.

**Aplikasi belum diuji langsung pada HP pengguna.** Jangan kirim secret, token, password atau log data sensitif.

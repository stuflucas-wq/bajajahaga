package id.ardensa.qrisbridge

import android.app.job.JobInfo
import android.app.job.JobParameters
import android.app.job.JobScheduler
import android.app.job.JobService
import android.content.ComponentName
import android.content.Context
import java.util.concurrent.Executors

class UploadJobService : JobService() {
    private val executor = Executors.newSingleThreadExecutor()

    override fun onStartJob(params: JobParameters): Boolean {
        BridgeDiagnostics.record(applicationContext, "job", "JobScheduler mulai memproses antrean")
        executor.execute {
            var failed = false
            var processed = 0
            while (processed < 50) {
                val item = NotificationQueue.first(applicationContext) ?: break
                if (NetworkSender.deliver(applicationContext, item)) {
                    NotificationQueue.remove(applicationContext, item.getString("event_id"))
                } else {
                    failed = true
                    break
                }
                processed++
            }
            // If pending and network still available, JobScheduler will retry.
            BridgeDiagnostics.record(applicationContext, "job", "Selesai: diproses=$processed; gagal=$failed; sisa=${NotificationQueue.size(applicationContext)}")
            jobFinished(params, failed || NotificationQueue.size(applicationContext) > 0)
        }
        return true
    }

    override fun onStopJob(params: JobParameters): Boolean = true

    companion object {
        private const val JOB_ID = 35822
        fun schedule(context: Context) {
            val scheduler = context.getSystemService(Context.JOB_SCHEDULER_SERVICE) as JobScheduler
            val job = JobInfo.Builder(JOB_ID, ComponentName(context, UploadJobService::class.java))
                .setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY)
                .setPersisted(true)
                .setBackoffCriteria(30000, JobInfo.BACKOFF_POLICY_EXPONENTIAL)
                .build()
            val result = scheduler.schedule(job)
            BridgeDiagnostics.record(context, "job", if (result == JobScheduler.RESULT_SUCCESS)
                "JobScheduler dijadwalkan (menunggu Android)" else "JobScheduler GAGAL menjadwalkan")
        }
    }
}

package id.ardensa.qrisbridge

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.provider.Settings
import android.text.TextUtils
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import org.json.JSONObject
import java.util.UUID

class MainActivity : Activity() {
    private lateinit var endpoint: EditText
    private lateinit var deviceId: EditText
    private lateinit var deviceSecret: EditText
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        window.setFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE, android.view.WindowManager.LayoutParams.FLAG_SECURE)
        endpoint = findViewById(R.id.endpoint)
        deviceId = findViewById(R.id.deviceId)
        deviceSecret = findViewById(R.id.deviceSecret)
        status = findViewById(R.id.status)
        endpoint.setText(ConfigStore.endpoint(this))
        deviceId.setText(ConfigStore.deviceId(this))
        deviceSecret.setText(ConfigStore.secret(this))
        findViewById<Button>(R.id.save).setOnClickListener {
            val url = endpoint.text.toString().trimEnd('/').trim()
            val id = deviceId.text.toString().trim()
            val key = deviceSecret.text.toString()
            if (!url.startsWith("https://") || !url.endsWith("/api/qris/notification") || id.isEmpty() || key.length < 32) {
                Toast.makeText(this, "Periksa URL HTTPS, ID dan secret minimal 32 karakter", Toast.LENGTH_LONG).show()
            } else {
                ConfigStore.save(this, url, id, key)
                Toast.makeText(this, "Konfigurasi tersimpan terenkripsi", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }
        findViewById<Button>(R.id.openAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        findViewById<Button>(R.id.scanNow).setOnClickListener {
            val result = GoPayNotificationListener.scanNow()
            Toast.makeText(this, result, Toast.LENGTH_LONG).show()
            refresh()
        }
        findViewById<Button>(R.id.rebind).setOnClickListener {
            val target = ComponentName(this, GoPayNotificationListener::class.java)
            try {
                NotificationListenerService.requestRebind(target)
                Toast.makeText(this, "Permintaan hubungkan ulang dikirim. Refresh setelah beberapa detik.", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                Toast.makeText(this, "Gagal meminta rebind: ${e.javaClass.simpleName}", Toast.LENGTH_LONG).show()
            }
            refresh()
        }
        findViewById<Button>(R.id.retry).setOnClickListener {
            val sendButton = findViewById<Button>(R.id.retry)
            sendButton.isEnabled = false
            BridgeDiagnostics.record(this, "upload", "Pengiriman langsung diminta")
            refresh()
            Thread {
                var message: String
                try {
                    val item = NotificationQueue.first(applicationContext)
                    if (item == null) {
                        message = "Antrean kosong; tidak ada event untuk dikirim"
                    } else {
                        BridgeDiagnostics.record(applicationContext, "upload", "Memulai POST event antrean")
                        val success = NetworkSender.deliver(applicationContext, item)
                        if (success) {
                            NotificationQueue.remove(applicationContext, item.getString("event_id"))
                            message = "Event diterima API. Periksa respons dan status invoice."
                            if (NotificationQueue.size(applicationContext) > 0) {
                                UploadJobService.schedule(applicationContext)
                            }
                        } else {
                            message = "Pengiriman gagal. Event disimpan, cek Respons API terakhir."
                        }
                    }
                } catch (e: Exception) {
                    message = "Gagal mengirim: ${e.javaClass.simpleName}"
                    BridgeDiagnostics.record(applicationContext, "upload", message)
                }
                BridgeDiagnostics.record(applicationContext, "upload", message)
                runOnUiThread {
                    sendButton.isEnabled = true
                    refresh()
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        findViewById<Button>(R.id.refreshDiagnostics).setOnClickListener { refresh() }
        findViewById<Button>(R.id.copyDiagnostics).setOnClickListener {
            val clip = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            clip.setPrimaryClip(ClipData.newPlainText("QRIS Diagnostik", diagnosticsText()))
            Toast.makeText(this, "Diagnostik disalin (tanpa secret)", Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.testApi).setOnClickListener {
            // Explicit connectivity test: never a payment notification or PAID candidate.
            val now = System.currentTimeMillis()
            val nonce = UUID.randomUUID().toString()
            val demo = JSONObject().apply {
                put("event_id", NotificationParser.sha256("diagnostic-test-$now-$nonce"))
                put("package_name", NotificationParser.GOPAY_PACKAGE)
                put("title", "TES KONEKSI QRIS BRIDGE")
                put("text", "Ini bukan pembayaran. Test koneksi API saja.")
                put("posted_at_ms", now)
            }
            Thread {
                val success = NetworkSender.deliver(applicationContext, demo)
                runOnUiThread {
                    refresh()
                    Toast.makeText(this, if (success) "API tersambung (tes bukan pembayaran)" else "Tes API gagal: lihat diagnostik", Toast.LENGTH_LONG).show()
                }
            }.start()
        }
        refresh()
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun diagnosticsText(): String {
        val enabled = Settings.Secure.getString(contentResolver, "enabled_notification_listeners") ?: ""
        val component = ComponentName(this, GoPayNotificationListener::class.java).flattenToString()
        val access = enabled.split(':').any { TextUtils.equals(it, component) }
        return """Versi: 1.3 Diagnostik
Akses notifikasi: ${if (access) "AKTIF" else "BELUM AKTIF"}
Status listener: ${BridgeDiagnostics.get(this,"service")}
Scan notifikasi aktif: ${BridgeDiagnostics.get(this,"scan")}
Event Android terakhir: ${BridgeDiagnostics.get(this,"received")}
Antrean menunggu: ${NotificationQueue.size(this)} event
Paket aplikasi sumber: ${NotificationParser.GOPAY_PACKAGE}
Notifikasi terakhir: ${BridgeDiagnostics.get(this,"listener")}
Antrean: ${BridgeDiagnostics.get(this,"queue")}
Pengiriman langsung: ${BridgeDiagnostics.get(this,"upload")}
JobScheduler: ${BridgeDiagnostics.get(this,"job")}
Respons API terakhir: ${BridgeDiagnostics.get(this,"network")}"""
    }

    private fun refresh() {
        status.text = diagnosticsText()
    }
}
